#!/bin/sh
make clean
tmake -o makefile zdbat.pro
make
