#!/bin/sh
export VERSION=`sed -e 's/"//g' version.txt`
find . -name 'moc_*' -o \( -name '*.cpp' -o -name '*.h' \) -print > srclist.txt
find ./ipkg \( -type f -o -type l \) -exec rm -f {} \;
cat ./srclist.txt ./fixedlist.txt > ./filelist.txt
tar -hzcvf ./dist/zdbat_${VERSION}_src.tar.gz -T ./filelist.txt
