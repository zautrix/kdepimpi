#!/bin/sh
export VERSION=`sed -e 's/"//g' version.txt`
find ./ipkg \( -type f -o -type l \) -exec rm -f {} \;
arm-linux-strip zdbat
cp -a zdbat ./ipkg/opt/QtPalmtop/bin/
sed "s/%VERSION%/$VERSION/" zdbat.control > ./ipkg/CONTROL/control
cd ./dist && ipkg-build ../ipkg
